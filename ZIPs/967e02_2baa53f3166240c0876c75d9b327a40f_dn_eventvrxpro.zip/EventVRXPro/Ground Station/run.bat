FlashProg.exe FW.bin
cmd